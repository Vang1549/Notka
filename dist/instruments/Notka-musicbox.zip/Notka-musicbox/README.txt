Музыкальная шкатулка

Music box — Joseph SARDIN / BigSoundBank, CC0 1.0.
https://bigsoundbank.com/boite-a-musique-do-1-s1867.html
https://bigsoundbank.com/music-box-c-2-s1874.html
https://bigsoundbank.com/boite-a-musique-Fa-2-s1877.html
Нотка: удаление начальной тишины, нормализация, настройка высоты, 32 кГц / 16 бит.

Те же WAV используются в Нотке. Моно, 32 кГц, 16 бит; один динамический слой. Ноты вне записанного диапазона транспонируются. SFZ можно открыть в совместимом сэмплере.
